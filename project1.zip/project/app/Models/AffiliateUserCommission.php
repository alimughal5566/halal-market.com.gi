<?php

namespace App\MOdels;

use Illuminate\Database\Eloquent\Model;

class AffiliateUserCommission extends Model
{
    protected $guarded = [
        '_token'
    ];
}
